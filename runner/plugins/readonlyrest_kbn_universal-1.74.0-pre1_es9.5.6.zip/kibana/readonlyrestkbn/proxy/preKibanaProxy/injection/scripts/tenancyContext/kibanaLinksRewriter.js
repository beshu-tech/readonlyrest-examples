"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var kibanaLinksRewriter_exports = {};
__export(kibanaLinksRewriter_exports, {
  KibanaLinksRewriter: () => KibanaLinksRewriter
});
module.exports = __toCommonJS(kibanaLinksRewriter_exports);
var import_queryStringKeys = require("../../../../../shared/constants/queryStringKeys");
const _KibanaLinksRewriter = class _KibanaLinksRewriter {
  constructor(tenancyUrlService) {
    this.tenancyUrlService = tenancyUrlService;
  }
  rewriteAllLinks() {
    document.querySelectorAll("a[href]").forEach((link) => this.rewriteLinkHref(link));
  }
  rewriteLinkHref(link) {
    if (link.dataset[_KibanaLinksRewriter.TENANT_APPLIED_MARKER]) {
      return;
    }
    const tenancyId = this.tenancyUrlService.getCurrentTenancy();
    link.dataset[_KibanaLinksRewriter.TENANT_APPLIED_MARKER] = "true";
    const hrefUrl = new URL(link.href, window.location.origin);
    hrefUrl.searchParams.set(import_queryStringKeys.TENANCY_QUERY_STRING_KEY, tenancyId);
    link.href = hrefUrl.toString();
  }
};
__publicField(_KibanaLinksRewriter, "TENANT_APPLIED_MARKER", "tenantApplied");
let KibanaLinksRewriter = _KibanaLinksRewriter;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaLinksRewriter
});
