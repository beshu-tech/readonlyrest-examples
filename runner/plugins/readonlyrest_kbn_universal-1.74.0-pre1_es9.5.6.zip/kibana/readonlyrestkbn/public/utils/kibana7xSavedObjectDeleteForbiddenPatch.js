"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibana7xSavedObjectDeleteForbiddenPatch_exports = {};
__export(kibana7xSavedObjectDeleteForbiddenPatch_exports, {
  interceptKibana7xSavedObjectCountsForbidden: () => interceptKibana7xSavedObjectCountsForbidden,
  patchKibana7xSavedObjectDeleteForbidden: () => patchKibana7xSavedObjectDeleteForbidden
});
module.exports = __toCommonJS(kibana7xSavedObjectDeleteForbiddenPatch_exports);
const SAVED_OBJECTS_PAGE_PATH = "/management/kibana/objects";
const INDEX_PATTERNS_PAGE_PATH = "/management/kibana/indexPatterns";
const DATA_VIEWS_PAGE_PATH = "/management/kibana/dataViews";
const MANAGEMENT_PAGE_PATHS = [SAVED_OBJECTS_PAGE_PATH, INDEX_PATTERNS_PAGE_PATH, DATA_VIEWS_PAGE_PATH];
const SAVED_OBJECTS_LIST_PAGE_PATH_PATTERN = /\/management\/kibana\/objects\/?$/;
const COUNTS_URL = "/api/kibana/management/saved_objects/scroll/counts";
const isForbiddenError = (error) => {
  var _a;
  return typeof error === "object" && error !== null && ((_a = error.response) == null ? void 0 : _a.status) === 403;
};
const patchKibana7xSavedObjectDeleteForbidden = (client, toasts, location = window.location) => {
  const originalDelete = client.delete.bind(client);
  const showForbiddenToast = (error) => {
    var _a;
    const message = (_a = error.body) == null ? void 0 : _a.message;
    toasts.addDanger({
      title: "Object could not be deleted",
      text: typeof message === "string" ? message : "You do not have permission to delete this object."
    });
  };
  client.delete = async (...args) => {
    try {
      return await originalDelete(...args);
    } catch (error) {
      if (!isForbiddenError(error)) throw error;
      if (MANAGEMENT_PAGE_PATHS.some((path) => location.pathname.includes(path))) {
        showForbiddenToast(error);
      }
      if (SAVED_OBJECTS_LIST_PAGE_PATH_PATTERN.test(location.pathname)) return void 0;
      throw error;
    }
  };
};
const interceptKibana7xSavedObjectCountsForbidden = (http, location = window.location) => http.intercept({
  responseError: (httpErrorResponse) => {
    var _a, _b, _c;
    if (((_a = httpErrorResponse.response) == null ? void 0 : _a.status) !== 403) return;
    if (!((_c = (_b = httpErrorResponse.request) == null ? void 0 : _b.url) == null ? void 0 : _c.includes(COUNTS_URL))) return;
    if (!location.pathname.includes(SAVED_OBJECTS_PAGE_PATH)) return;
    return { body: {} };
  }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  interceptKibana7xSavedObjectCountsForbidden,
  patchKibana7xSavedObjectDeleteForbidden
});
