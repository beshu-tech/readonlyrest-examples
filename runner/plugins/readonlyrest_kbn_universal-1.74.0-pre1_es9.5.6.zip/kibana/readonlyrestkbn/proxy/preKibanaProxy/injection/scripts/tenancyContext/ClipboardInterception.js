"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var ClipboardInterception_exports = {};
__export(ClipboardInterception_exports, {
  ClipboardInterception: () => ClipboardInterception
});
module.exports = __toCommonJS(ClipboardInterception_exports);
var import_queryStringKeys = require("../../../../../shared/constants/queryStringKeys");
const _ClipboardInterception = class _ClipboardInterception {
  constructor(tenancyUrlService, tenancyContextApplier) {
    this.tenancyUrlService = tenancyUrlService;
    this.tenancyContextApplier = tenancyContextApplier;
  }
  setupClipboardInterception() {
    document.addEventListener("copy", (event) => {
      var _a;
      const selectedText = (_a = document.getSelection()) == null ? void 0 : _a.toString();
      if (!selectedText) {
        return;
      }
      if (selectedText.includes("<iframe")) {
        this.interceptEmbedDashboardCopyLink(selectedText, event);
        return;
      }
      if (_ClipboardInterception.INTERCEPTED_PATHS.some((path) => selectedText.includes(path))) {
        this.interceptUrlCopyLink(selectedText, event);
      }
    });
  }
  interceptEmbedDashboardCopyLink(copiedText, event) {
    var _a;
    const currentTenancyId = this.tenancyUrlService.getCurrentTenancy();
    const copiedUrl = this.tenancyContextApplier.addTenancyToIframeString(copiedText, currentTenancyId);
    (_a = event.clipboardData) == null ? void 0 : _a.setData("text/plain", copiedUrl.toString());
    event.preventDefault();
  }
  interceptUrlCopyLink(copiedText, event) {
    var _a;
    const copiedUrl = new URL(copiedText);
    const currentTenancyId = this.tenancyUrlService.getCurrentTenancy();
    copiedUrl.searchParams.set(import_queryStringKeys.TENANCY_QUERY_STRING_KEY, currentTenancyId);
    (_a = event.clipboardData) == null ? void 0 : _a.setData("text/plain", copiedUrl.toString());
    event.preventDefault();
  }
};
__publicField(_ClipboardInterception, "SHARED_SPACE_PATH", "/app/r/s/");
__publicField(_ClipboardInterception, "GOTO_PATH", "/goto/");
__publicField(_ClipboardInterception, "LOCATOR_PATH", "/app/r?l=");
__publicField(_ClipboardInterception, "INTERCEPTED_PATHS", [
  _ClipboardInterception.GOTO_PATH,
  _ClipboardInterception.SHARED_SPACE_PATH,
  _ClipboardInterception.LOCATOR_PATH
]);
let ClipboardInterception = _ClipboardInterception;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ClipboardInterception
});
