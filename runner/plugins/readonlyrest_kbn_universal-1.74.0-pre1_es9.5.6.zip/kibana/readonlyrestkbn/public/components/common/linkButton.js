"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var linkButton_exports = {};
__export(linkButton_exports, {
  default: () => linkButton_default
});
module.exports = __toCommonJS(linkButton_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react = require("react");
var import_buttonEmpty = require("./buttonEmpty");
function LinkButton({ children, onClick, isSelected, isFocused, style, contentJustify = "flex-end" }) {
  const [isHovered, setIsHover] = (0, import_react.useState)(false);
  const isHighlighted = isSelected || isHovered || isFocused;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_buttonEmpty.ButtonEmpty,
    {
      color: "text",
      contentProps: {
        style: {
          justifyContent: contentJustify
        }
      },
      style: {
        cursor: isSelected ? "default" : "pointer",
        padding: "8px",
        border: "none",
        boxShadow: "none",
        transform: "none",
        backgroundColor: isHighlighted ? "rgba(211,218,230,.25)" : "initial",
        width: "100%",
        height: "100%",
        textDecoration: isHovered ? "underline" : "none",
        // Keyboard focus indicator - subtle outline
        outline: isFocused ? "2px solid rgba(0, 119, 204, 0.5)" : "none",
        outlineOffset: "-2px",
        ...style
      },
      onClick,
      onMouseOver: () => setIsHover(true),
      onMouseLeave: () => setIsHover(false),
      children
    }
  );
}
var linkButton_default = LinkButton;
