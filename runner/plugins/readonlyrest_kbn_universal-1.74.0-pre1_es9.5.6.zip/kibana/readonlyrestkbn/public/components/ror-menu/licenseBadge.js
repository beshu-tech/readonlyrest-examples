"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var licenseBadge_exports = {};
__export(licenseBadge_exports, {
  LicenseBadge: () => LicenseBadge,
  default: () => licenseBadge_default
});
module.exports = __toCommonJS(licenseBadge_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
var import_ActivationKey = require("../../../shared/types/ActivationKey");
function LicenseBadge({ info, showSecuritySettings, openActivationKeyTab }) {
  const getExpiresIn = () => {
    var _a, _b;
    function daysUntilNow(epochSeconds) {
      const A_DAY_IN_MILLISECONDS = 1e3 * 60 * 60 * 24;
      const now = /* @__PURE__ */ new Date();
      const expirationDate = new Date(epochSeconds * 1e3);
      const diff = expirationDate.getTime() - now.getTime();
      return Math.ceil(diff / A_DAY_IN_MILLISECONDS);
    }
    return daysUntilNow((_b = (_a = info.licenseInfo) == null ? void 0 : _a.exp) != null ? _b : -1);
  };
  const licenseBadgeColor = () => {
    var _a;
    const edition = (_a = info.licenseInfo) == null ? void 0 : _a.license.edition;
    if (edition === import_ActivationKey.EDITIONS_ENUM.FREE) {
      return "#4DD2CA";
    }
    const days2Expiry = getExpiresIn();
    if (days2Expiry < 30) {
      return "#BD271E";
    }
    return "#0077CC";
  };
  const licenseBadgeIcon = () => {
    var _a;
    const edition = (_a = info.licenseInfo) == null ? void 0 : _a.license.edition;
    if (edition === import_ActivationKey.EDITIONS_ENUM.FREE) {
      return "pencil";
    }
    const days2Expiry = getExpiresIn();
    if (days2Expiry < 30) {
      return "alert";
    }
    return "check";
  };
  const licenseBadgeText = () => {
    var _a, _b, _c;
    const edition = (_a = info.licenseInfo) == null ? void 0 : _a.license.edition;
    const editionName = (_c = (_b = info.licenseInfo) == null ? void 0 : _b.license.edition_name) != null ? _c : "UNKNOWN";
    if (edition === import_ActivationKey.EDITIONS_ENUM.FREE) {
      return editionName;
    }
    const days2Expiry = Math.max(0, getExpiresIn());
    if (days2Expiry < 30) {
      return `${editionName} (expires in ${days2Expiry} days!)`;
    }
    return editionName;
  };
  const licenseTooltipText = () => {
    var _a;
    const edition = (_a = info.licenseInfo) == null ? void 0 : _a.license.edition;
    return edition === import_ActivationKey.EDITIONS_ENUM.FREE ? "Add activation key" : "Edit activation key";
  };
  const canSeeActivationKey = Boolean(
    (info == null ? void 0 : info.identity.kibanaAccess) === "admin" || (info == null ? void 0 : info.identity.kibanaAccess) === "unrestricted"
  );
  if (showSecuritySettings() && canSeeActivationKey) {
    return (
      /* @ts-ignore */
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiToolTip, { content: licenseTooltipText(), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_eui.EuiBadge,
        {
          onClick: openActivationKeyTab,
          onClickAriaLabel: "open-activation-key",
          iconOnClick: openActivationKeyTab,
          iconOnClickAriaLabel: "icon-open-activation-key",
          style: { width: "fit-content", marginLeft: "8px", borderRadius: "4px" },
          color: licenseBadgeColor(),
          iconType: licenseBadgeIcon(),
          children: licenseBadgeText()
        }
      ) })
    );
  }
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_eui.EuiBadge,
    {
      style: { width: "fit-content", marginLeft: "8px" },
      color: licenseBadgeColor(),
      iconType: licenseBadgeIcon(),
      children: licenseBadgeText()
    }
  );
}
var licenseBadge_default = LicenseBadge;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LicenseBadge
});
