"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var expiryDate_exports = {};
__export(expiryDate_exports, {
  default: () => expiryDate_default
});
module.exports = __toCommonJS(expiryDate_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react = require("react");
var import_pretty_ms = __toESM(require("pretty-ms"));
var import_useCountdown = require("./useCountdown");
function ExpiryDate({ validTo, handleTtlExpiry }) {
  const date = (0, import_useCountdown.useCountdown)(validTo);
  const humanReadableDate = (0, import_pretty_ms.default)(date, { secondsDecimalDigits: 0 });
  (0, import_react.useEffect)(() => {
    if (date === 0 && handleTtlExpiry) {
      handleTtlExpiry();
    }
  }, [date, handleTtlExpiry]);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: humanReadableDate });
}
var expiryDate_default = ExpiryDate;
