"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var plugin_exports = {};
__export(plugin_exports, {
  ReadonlyrestKbnPlugin: () => ReadonlyrestKbnPlugin
});
module.exports = __toCommonJS(plugin_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react_dom = __toESM(require("react-dom"));
var import_rorMenu = require("./components/rorMenu");
var import_coreFunctions = __toESM(require("./utils/coreFunctions"));
var import_infoApiResponse = require("../shared/models/infoApiResponse");
var import_ActivationKey = require("../shared/types/ActivationKey");
var import_themeProvider = require("./providers/themeProvider");
var import_mountPageNotFound = require("./components/page-not-found/mountPageNotFound");
var import_rorFetch = require("./utils/rorFetch");
var import_wireForbiddenResponseHandlers = require("./utils/wireForbiddenResponseHandlers");
var import_persistentMountPoint = require("./utils/persistentMountPoint");
class ReadonlyrestKbnPlugin {
  constructor(initializerContext) {
    __publicField(this, "kibanaVersion");
    __publicField(this, "info", new import_infoApiResponse.InfoApiResponse(
      {
        username: "",
        availableGroups: [],
        correlationId: "",
        kibanaAccess: "",
        impersonatedBy: "",
        currentGroup: void 0,
        kibanaHiddenApps: []
      },
      void 0,
      void 0,
      "",
      { clearSessionOnEvents: ["login", "tenancyHop"], logoutLink: "/logout" }
    ));
    this.kibanaVersion = initializerContext.env.packageInfo.version;
  }
  setup(core) {
    const mountPageNotFound = new import_mountPageNotFound.MountPageNotFound(this.kibanaVersion);
    mountPageNotFound.registerPageNotFoundPage(core);
    return {};
  }
  async start(core) {
    var _a, _b;
    import_coreFunctions.default.initialization(core);
    (0, import_wireForbiddenResponseHandlers.wireForbiddenResponseHandlers)(core, this.kibanaVersion);
    const response = await (0, import_rorFetch.rorFetch)(`${import_coreFunctions.default.serverBasePathPrepend("/pkp")}/api/info`);
    this.info = await response.json();
    console.log(">> info ", this.info);
    import_coreFunctions.default.overwriteKibanaContent(
      this.kibanaVersion,
      (_b = (_a = this.info.licenseInfo) == null ? void 0 : _a.license.edition) != null ? _b : import_ActivationKey.EDITIONS_ENUM.FREE
    );
    core.chrome.navControls.registerRight({
      order: 1e4,
      mount: (0, import_persistentMountPoint.persistentMountPoint)((container) => this.renderMenu(container))
    });
    return {};
  }
  renderMenu(container) {
    const redirectToLogout = this.info.config.logoutLink;
    import_react_dom.default.render(
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_themeProvider.ThemeProvider, { kibanaVersion: this.kibanaVersion, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_rorMenu.RorMenu,
        {
          pkpBasePath: import_coreFunctions.default.serverBasePathPrepend("/pkp"),
          logoutRedirect: redirectToLogout,
          clearSessionOnEvents: this.info.config.clearSessionOnEvents,
          info: this.info
        }
      ) }),
      container
    );
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ReadonlyrestKbnPlugin
});
