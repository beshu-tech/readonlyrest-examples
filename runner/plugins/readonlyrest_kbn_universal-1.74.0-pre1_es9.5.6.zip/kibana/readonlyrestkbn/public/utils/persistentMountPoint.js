"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var persistentMountPoint_exports = {};
__export(persistentMountPoint_exports, {
  persistentMountPoint: () => persistentMountPoint
});
module.exports = __toCommonJS(persistentMountPoint_exports);
var import_react_dom = __toESM(require("react-dom"));
function persistentMountPoint(render) {
  let container;
  return (target) => {
    const mounted = container != null ? container : document.createElement("div");
    mounted.style.display = "contents";
    target.appendChild(mounted);
    if (mounted !== container) {
      try {
        render(mounted);
      } catch (e) {
        mounted.remove();
        throw e;
      }
      container = mounted;
    }
    return () => {
      if (mounted.parentNode === target) {
        mounted.remove();
      }
      queueMicrotask(() => {
        if (!mounted.isConnected && container === mounted) {
          import_react_dom.default.unmountComponentAtNode(mounted);
          container = void 0;
        }
      });
    };
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  persistentMountPoint
});
