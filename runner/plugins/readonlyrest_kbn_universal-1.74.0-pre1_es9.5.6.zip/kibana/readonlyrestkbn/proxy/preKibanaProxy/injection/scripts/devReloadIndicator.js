/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

function init() {
  const DEV_RELOAD_EVENTS_URL = '${devReloadEventsUrl}';
  const KIBANA_RELOAD_INDICATOR_ATTRIBUTE = 'data-ror-kibana-reload-indicator';

  function getReloadIndicatorDocuments() {
    const documents = [document];
    const webAppDocument = document.getElementById('readonlyrestIframe')?.contentDocument;
    if (webAppDocument?.body) {
      documents.push(webAppDocument);
    }
    return documents;
  }

  function showKibanaReloadIndicator() {
    for (const targetDocument of getReloadIndicatorDocuments()) {
      if (targetDocument.querySelector(`[${KIBANA_RELOAD_INDICATOR_ATTRIBUTE}]`)) {
        continue;
      }

      const overlay = targetDocument.createElement('div');
      overlay.setAttribute(KIBANA_RELOAD_INDICATOR_ATTRIBUTE, '');
      overlay.setAttribute('role', 'status');
      overlay.setAttribute('aria-live', 'polite');
      overlay.setAttribute('aria-atomic', 'true');
      Object.assign(overlay.style, {
        position: 'fixed',
        inset: '0',
        zIndex: '2147483647',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px',
        background: 'rgba(16, 24, 40, 0.72)',
        backdropFilter: 'blur(2px)'
      });

      const message = targetDocument.createElement('div');
      Object.assign(message.style, {
        maxWidth: '420px',
        padding: '24px',
        border: '1px solid rgba(255, 255, 255, 0.18)',
        borderRadius: '8px',
        color: '#ffffff',
        background: '#1d2939',
        boxShadow: '0 12px 32px rgba(0, 0, 0, 0.28)',
        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        textAlign: 'center'
      });

      const title = targetDocument.createElement('strong');
      title.textContent = 'Kibana is reloading';
      Object.assign(title.style, {
        display: 'block',
        marginBottom: '8px',
        fontSize: '18px',
        lineHeight: '24px'
      });

      const description = targetDocument.createElement('span');
      description.textContent = 'Your session is preserved. Reconnecting automatically…';
      Object.assign(description.style, {
        display: 'block',
        color: '#d0d5dd',
        fontSize: '14px',
        lineHeight: '20px'
      });

      message.append(title, description);
      overlay.append(message);
      targetDocument.body.append(overlay);
    }
  }

  function hideKibanaReloadIndicator() {
    for (const targetDocument of getReloadIndicatorDocuments()) {
      targetDocument.querySelector(`[${KIBANA_RELOAD_INDICATOR_ATTRIBUTE}]`)?.remove();
    }
  }

  if (typeof EventSource === 'undefined') {
    return;
  }

  const reloadEvents = new EventSource(DEV_RELOAD_EVENTS_URL);
  reloadEvents.addEventListener('reload', showKibanaReloadIndicator);
  reloadEvents.addEventListener('ready', hideKibanaReloadIndicator);
}

init();
