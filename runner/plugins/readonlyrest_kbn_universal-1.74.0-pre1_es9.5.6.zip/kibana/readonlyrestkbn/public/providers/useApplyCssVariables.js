"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var useApplyCssVariables_exports = {};
__export(useApplyCssVariables_exports, {
  mapToCssVariables: () => mapToCssVariables,
  useApplyCssVariables: () => useApplyCssVariables
});
module.exports = __toCommonJS(useApplyCssVariables_exports);
var import_react = require("react");
const mapToCssVariables = (obj, prefix = "--ror") => {
  const cssVariables = {};
  Object.entries(obj).forEach(([key, value]) => {
    const varName = `${prefix}-${key}`;
    cssVariables[varName] = value;
  });
  return cssVariables;
};
const setCssVariables = (obj) => {
  const root = document.documentElement;
  Object.entries(obj).forEach(([key, value]) => {
    root.style.setProperty(key, value);
  });
};
const useApplyCssVariables = ({ theme }) => {
  const cssVariables = (0, import_react.useMemo)(() => mapToCssVariables(theme.colors), [theme.colors]);
  (0, import_react.useLayoutEffect)(() => {
    setCssVariables(cssVariables);
    document.body.setAttribute("data-theme", theme.variant);
  }, [cssVariables, theme]);
  return { cssVariables };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  mapToCssVariables,
  useApplyCssVariables
});
