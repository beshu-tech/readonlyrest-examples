"use strict";
(() => {
  // proxy/preKibanaProxy/injection/scripts/unsupportedEndpointsFilter.ts
  var BLOCKED_XPACK_PATTERNS = [
    "_record_auth_type",
    // records which auth provider (SAML/OIDC/basic) was used — irrelevant when ROR manages auth
    "productUpgradeInterceptTrigger",
    // triggers upgrade prompts for paid Elastic tiers — not applicable with ROR licensing
    "productTrialInterceptTrigger",
    // triggers trial-start prompts for Elastic subscriptions — not applicable with ROR licensing
    "productInterceptTrigger",
    // generic Elastic product upsell intercept — not applicable with ROR licensing
    "access_control/global_access",
    // Kibana 9.4+ dashboard/discover access control check — Kibana security plugin not active with ROR
    "/internal/user_storage/navigation"
    // Kibana 9.2+ nav customization storage — needs a native user profile, unavailable with ROR
  ];
  var USER_PROFILE_PATTERN = "/security/user_profile";
  var EMPTY_USER_PROFILE = JSON.stringify({
    uid: "",
    enabled: true,
    user: { username: "", realm_name: "", roles: [], full_name: null, email: null, metadata: {}, active: true },
    labels: {},
    data: { avatar: { type: "initials", initials: "", color: "#6092C0" } }
  });
  var CURRENT_USERNAME = "${currentUsername}";
  var SECURITY_ME_PATTERN = "/internal/security/me";
  var CURRENT_USER = JSON.stringify({
    username: CURRENT_USERNAME,
    roles: [],
    full_name: null,
    email: null,
    metadata: {},
    enabled: true,
    authentication_realm: { name: "ror", type: "ror" },
    lookup_realm: { name: "ror", type: "ror" },
    authentication_type: "realm",
    authentication_provider: { type: "basic", name: "basic1" },
    elastic_cloud_user: false
  });
  var originalFetch = window.fetch.bind(window);
  window.fetch = function(input, init) {
    let url;
    if (typeof input === "string") url = input;
    else if (input instanceof URL) url = input.href;
    else url = input.url;
    if (url) {
      if (url.indexOf(USER_PROFILE_PATTERN) !== -1) {
        return Promise.resolve(
          new Response(EMPTY_USER_PROFILE, {
            status: 200,
            statusText: "Not Implemented: ".concat(url, " endpoint is ignored by ReadonlyREST plugin"),
            headers: { "Content-Type": "application/json" }
          })
        );
      }
      if (url.indexOf(SECURITY_ME_PATTERN) !== -1) {
        return Promise.resolve(
          new Response(CURRENT_USER, {
            status: 200,
            statusText: "Not Implemented: ".concat(url, " endpoint is ignored by ReadonlyREST plugin"),
            headers: { "Content-Type": "application/json" }
          })
        );
      }
      if (BLOCKED_XPACK_PATTERNS.some((pattern) => url.indexOf(pattern) !== -1)) {
        return Promise.resolve(
          new Response("{}", {
            status: 200,
            statusText: "Not Implemented: ".concat(url, " endpoint is ignored by ReadonlyREST plugin"),
            headers: { "Content-Type": "application/json" }
          })
        );
      }
    }
    return originalFetch(input, init);
  };
})();
