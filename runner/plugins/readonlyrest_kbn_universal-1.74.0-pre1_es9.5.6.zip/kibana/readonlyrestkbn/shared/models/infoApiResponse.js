"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var infoApiResponse_exports = {};
__export(infoApiResponse_exports, {
  InfoApiResponse: () => InfoApiResponse
});
module.exports = __toCommonJS(infoApiResponse_exports);
class InfoApiResponse {
  constructor(identity, licenseInfo, distribution, cluster_uuid, config) {
    this.identity = identity;
    this.licenseInfo = licenseInfo;
    this.distribution = distribution;
    this.cluster_uuid = cluster_uuid;
    this.config = config;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  InfoApiResponse
});
