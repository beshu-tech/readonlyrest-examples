"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var windowOpenInterceptor_exports = {};
__export(windowOpenInterceptor_exports, {
  WindowOpenInterceptor: () => WindowOpenInterceptor
});
module.exports = __toCommonJS(windowOpenInterceptor_exports);
var import_queryStringKeys = require("../../../../../shared/constants/queryStringKeys");
class WindowOpenInterceptor {
  constructor(tenancyUrlService) {
    this.tenancyUrlService = tenancyUrlService;
  }
  intercept() {
    const originalOpen = window.open;
    window.open = (url, target, features) => {
      const interceptedUrls = ["/api/reporting/jobs/download/"];
      if (typeof url === "string" && interceptedUrls.some((interceptedUrl) => url.includes(interceptedUrl))) {
        const originURL = new URL(url, window.location.origin);
        if (!originURL.searchParams.has(import_queryStringKeys.TENANCY_QUERY_STRING_KEY)) {
          originURL.searchParams.set(import_queryStringKeys.TENANCY_QUERY_STRING_KEY, this.tenancyUrlService.getCurrentTenancy());
        }
        return originalOpen.call(window, originURL.toString(), target, features);
      }
      return originalOpen.call(window, url, target, features);
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  WindowOpenInterceptor
});
