"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var hiddenAppsChecker_exports = {};
__export(hiddenAppsChecker_exports, {
  hiddenAppsChecker: () => hiddenAppsChecker
});
module.exports = __toCommonJS(hiddenAppsChecker_exports);
function hiddenAppsChecker(expression, appId, logger) {
  const isRegexExpression = expression.startsWith("/") && expression.endsWith("/");
  try {
    const regExp = isRegexExpression ? unwrapRegexLiteral(expression) : buildPrefixMatchRegex(expression);
    return regExp.test(appId);
  } catch (e) {
    logger.error({ message: `Invalid regular expression: ${expression} Ignoring! ${e.message}`, stack: e.stack });
    return false;
  }
}
function unwrapRegexLiteral(expression) {
  const regexBody = expression.substring(1).slice(0, -1);
  return new RegExp(regexBody);
}
function buildPrefixMatchRegex(expression) {
  return new RegExp(`${expression.replace(/\|/g, "\\|")}.*`, "g");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  hiddenAppsChecker
});
