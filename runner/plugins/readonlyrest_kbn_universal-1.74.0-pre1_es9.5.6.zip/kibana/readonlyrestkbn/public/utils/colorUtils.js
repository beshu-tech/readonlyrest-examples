"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var colorUtils_exports = {};
__export(colorUtils_exports, {
  BADGE_STYLE_CONSTANTS: () => BADGE_STYLE_CONSTANTS,
  EUI_VIS_COLORS: () => EUI_VIS_COLORS,
  getColorFromString: () => getColorFromString,
  getContrastingTextColor: () => getContrastingTextColor,
  getTenantAvatarProps: () => getTenantAvatarProps
});
module.exports = __toCommonJS(colorUtils_exports);
const EUI_VIS_COLORS = [
  "#54B399",
  "#6092C0",
  "#D36086",
  "#9170B8",
  "#CA8EAE",
  "#D6BF57",
  "#B9A888",
  "#DA8B45",
  "#AA6556",
  "#E7664C"
];
const getColorFromString = (name, palette = EUI_VIS_COLORS) => {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return palette[Math.abs(hash) % palette.length];
};
const BADGE_STYLE_CONSTANTS = {
  borderRadius: "4px",
  fontWeight: 600,
  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
};
const sRGBtoLinear = (value) => {
  const normalized = value / 255;
  return normalized <= 0.04045 ? normalized / 12.92 : ((normalized + 0.055) / 1.055) ** 2.4;
};
const getLuminance = (hexColor) => {
  const hex = hexColor.replace("#", "");
  const r = sRGBtoLinear(parseInt(hex.substring(0, 2), 16));
  const g = sRGBtoLinear(parseInt(hex.substring(2, 4), 16));
  const b = sRGBtoLinear(parseInt(hex.substring(4, 6), 16));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
const getContrastingTextColor = (bgColor) => getLuminance(bgColor) > 0.5 ? "#000000" : "#FFFFFF";
const getTenantAvatarProps = (tenantName, maxLength) => {
  const bgColor = getColorFromString(tenantName);
  const result = {
    initial: tenantName.charAt(0).toUpperCase(),
    bgColor,
    textColor: getContrastingTextColor(bgColor)
  };
  if (maxLength !== void 0) {
    result.isTruncated = tenantName.length > maxLength;
    result.displayName = result.isTruncated ? tenantName.substring(0, maxLength) : tenantName;
  }
  return result;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BADGE_STYLE_CONSTANTS,
  EUI_VIS_COLORS,
  getColorFromString,
  getContrastingTextColor,
  getTenantAvatarProps
});
