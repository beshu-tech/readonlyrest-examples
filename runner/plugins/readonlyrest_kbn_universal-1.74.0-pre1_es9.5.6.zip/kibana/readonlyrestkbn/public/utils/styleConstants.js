"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var styleConstants_exports = {};
__export(styleConstants_exports, {
  ACCESS_BADGE_COLORS: () => ACCESS_BADGE_COLORS,
  ACCESS_LEVEL_CONFIG: () => ACCESS_LEVEL_CONFIG,
  ACTION_BUTTON_HOVER_COLORS: () => ACTION_BUTTON_HOVER_COLORS,
  ACTION_BUTTON_STYLE_BASE: () => ACTION_BUTTON_STYLE_BASE,
  AVATAR_STYLE_BASE: () => AVATAR_STYLE_BASE,
  ELLIPSIS_TEXT_STYLE: () => ELLIPSIS_TEXT_STYLE,
  FOCUS_COLORS: () => FOCUS_COLORS,
  MARQUEE_CONFIG: () => MARQUEE_CONFIG,
  ROR_BASE_TYPOGRAPHY: () => ROR_BASE_TYPOGRAPHY,
  ROR_FONT_FAMILY: () => ROR_FONT_FAMILY,
  USER_SECTION_STYLES: () => USER_SECTION_STYLES,
  Z_INDEX: () => Z_INDEX,
  accessBadgeStyle: () => accessBadgeStyle
});
module.exports = __toCommonJS(styleConstants_exports);
const ROR_FONT_FAMILY = 'var(--euiFontFamily, "Inter UI", -apple-system, "system-ui", "Segoe UI", Helvetica, Arial, sans-serif)';
const ROR_BASE_TYPOGRAPHY = {
  fontFamily: ROR_FONT_FAMILY,
  fontSize: "14px",
  lineHeight: "1.4"
};
const ELLIPSIS_TEXT_STYLE = {
  whiteSpace: "nowrap",
  overflow: "hidden",
  textOverflow: "ellipsis",
  display: "block"
};
const Z_INDEX = {
  /** Settings iframe overlay */
  iframe: 999,
  /** Notification badges on buttons */
  badge: 9e3,
  /** Nested popovers (must be above badges) */
  popoverNested: 9001
};
const FOCUS_COLORS = {
  /** Primary focus/hover color - uses EUI variable with fallback */
  primary: "var(--euiColorPrimary, #0077cc)"
};
const MARQUEE_CONFIG = {
  /** Default scroll speed for marquee animations */
  speed: 25,
  /** Slightly faster speed for compact spaces (e.g., header badge) */
  speedCompact: 30,
  /** Standard gap between repeated text */
  itemPadding: "32px",
  /** Tighter gap for compact displays */
  itemPaddingCompact: "24px"
};
const ACCESS_LEVEL_CONFIG = {
  ro: { label: "Read Only", shortLabel: "ro" },
  ro_strict: { label: "Read Only (Strict)", shortLabel: "rs" },
  rw: { label: "Read / Write", shortLabel: "rw" },
  admin: { label: "Admin", shortLabel: "a" },
  unrestricted: { label: "Unrestricted", shortLabel: "u" }
};
const ACCESS_BADGE_COLORS = {
  text: "#DD0A73",
  background: "#fdf0f5"
};
const accessBadgeStyle = (color, bgColor) => ({
  display: "inline-flex",
  padding: "2px 8px",
  borderRadius: "12px",
  backgroundColor: bgColor,
  color,
  fontSize: "11px",
  fontWeight: 500,
  width: "fit-content"
});
const USER_SECTION_STYLES = {
  /** Container for user sections with vertical layout */
  container: {
    display: "flex",
    flexDirection: "column",
    gap: "12px"
  },
  /** Row layout for avatar + user info */
  userRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
    width: "100%"
  },
  /** Username text style */
  username: {
    ...ELLIPSIS_TEXT_STYLE,
    fontWeight: 600,
    fontSize: "14px",
    lineHeight: "1.2"
  }
};
const AVATAR_STYLE_BASE = {
  width: "36px",
  height: "36px",
  borderRadius: "50%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0
};
const ACTION_BUTTON_STYLE_BASE = {
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "6px",
  padding: "8px 12px",
  borderRadius: "6px",
  fontSize: "13px",
  fontWeight: 500,
  cursor: "pointer",
  transition: "all 0.15s ease",
  width: "100%",
  backgroundColor: "transparent"
};
const ACTION_BUTTON_HOVER_COLORS = {
  /** Light red for danger actions (logout) */
  danger: "#fef6f6",
  /** Light amber for warning actions (exit impersonation) */
  warning: "#fef3c7"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ACCESS_BADGE_COLORS,
  ACCESS_LEVEL_CONFIG,
  ACTION_BUTTON_HOVER_COLORS,
  ACTION_BUTTON_STYLE_BASE,
  AVATAR_STYLE_BASE,
  ELLIPSIS_TEXT_STYLE,
  FOCUS_COLORS,
  MARQUEE_CONFIG,
  ROR_BASE_TYPOGRAPHY,
  ROR_FONT_FAMILY,
  USER_SECTION_STYLES,
  Z_INDEX,
  accessBadgeStyle
});
