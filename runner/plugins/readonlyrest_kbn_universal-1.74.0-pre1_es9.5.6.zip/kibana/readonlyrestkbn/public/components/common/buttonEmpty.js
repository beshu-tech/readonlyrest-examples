"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buttonEmpty_exports = {};
__export(buttonEmpty_exports, {
  ButtonEmpty: () => ButtonEmpty
});
module.exports = __toCommonJS(buttonEmpty_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
function ButtonEmpty({
  className,
  children,
  style,
  color = "primary",
  textProps,
  contentProps,
  onClick,
  onMouseOver,
  onMouseLeave
}) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_eui.EuiButtonEmpty,
    {
      contentProps,
      onMouseOver,
      onMouseLeave,
      onClick,
      textProps,
      color,
      style,
      className,
      children
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ButtonEmpty
});
