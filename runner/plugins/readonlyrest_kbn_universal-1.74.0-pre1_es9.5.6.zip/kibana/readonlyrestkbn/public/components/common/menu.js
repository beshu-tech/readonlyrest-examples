"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var menu_exports = {};
__export(menu_exports, {
  default: () => menu_default
});
module.exports = __toCommonJS(menu_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react = require("react");
var import_popover = require("./popover");
var import_flexGroup = require("./flexGroup");
var import_search = __toESM(require("./search"));
var import_spacer = require("./spacer");
var import_MenuItemRow = require("./MenuItemRow");
var import_hooks = require("../../hooks");
var import_styleConstants = require("../../utils/styleConstants");
let idCounter = 0;
function useStableId() {
  const idRef = (0, import_react.useRef)(null);
  if (idRef.current === null) {
    idCounter += 1;
    idRef.current = `ror-${idCounter}`;
  }
  return idRef.current;
}
const MENU_SEARCH_WIDTH = "234px";
const MENU_MAX_HEIGHT = "250px";
function MenuContent({ items, selectedGroup, search, renderItem, onItemSelect, onClose }) {
  const scrollContainerRef = (0, import_react.useRef)(null);
  const selectedIndex = (0, import_react.useMemo)(
    () => items.findIndex((item) => !item.isHeader && (selectedGroup == null ? void 0 : selectedGroup.name) === item.title),
    [items, selectedGroup]
  );
  const { focusedIndex } = (0, import_hooks.useMenuKeyboardNavigation)({
    items,
    selectedIndex,
    resetTrigger: search == null ? void 0 : search.value,
    onSelect: (_index, item) => {
      onItemSelect(item, {});
    },
    onClose
  });
  (0, import_react.useLayoutEffect)(() => {
    if (focusedIndex >= 0 && scrollContainerRef.current) {
      const focusedElement = scrollContainerRef.current.querySelector(`[data-menu-index="${focusedIndex}"]`);
      if (focusedElement && typeof focusedElement.scrollIntoView === "function") {
        focusedElement.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }
    }
  }, [focusedIndex]);
  const getGroupStyle = () => {
    const style = {
      overflow: "auto",
      maxHeight: MENU_MAX_HEIGHT,
      // Hide scrollbar while maintaining scroll functionality (Firefox/IE/Edge)
      scrollbarWidth: "none",
      msOverflowStyle: "none"
    };
    if (search) {
      style.minHeight = MENU_MAX_HEIGHT;
      style.width = MENU_SEARCH_WIDTH;
    }
    return style;
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    search && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_search.default,
        {
          value: search.value,
          placeholder: search.placeholder,
          onChange: search.onChange,
          isClearable: search.isClearable,
          style: { width: MENU_SEARCH_WIDTH },
          autoFocus: true
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_spacer.Spacer, { size: "m" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: scrollContainerRef, className: "ror-menu-scroll-container", style: getGroupStyle(), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_flexGroup.FlexGroup, { direction: "column", gutterSize: "s", children: items.map((menuItem, index) => {
      var _a;
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_MenuItemRow.MenuItemRow,
        {
          item: menuItem,
          index,
          isSelected: (selectedGroup == null ? void 0 : selectedGroup.name) === menuItem.title,
          isFocused: focusedIndex === index,
          renderItem,
          onItemClick: onItemSelect
        },
        (_a = menuItem.id) != null ? _a : `${menuItem.title}-${index}`
      );
    }) }) })
  ] });
}
function Menu({ id, button, isOpen, handleClose, closeMainMenu, items, selectedGroup, search, renderItem }) {
  const generatedId = useStableId();
  const popoverId = id != null ? id : `ror-menu-${generatedId}`;
  const handleItemSelect = (item, event) => {
    var _a;
    (_a = item.action) == null ? void 0 : _a.call(item, event);
    handleClose();
    closeMainMenu == null ? void 0 : closeMainMenu();
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_popover.Popover,
    {
      button,
      closePopover: handleClose,
      style: { display: "grid" },
      id: popoverId,
      isOpen,
      anchorPosition: "leftDown",
      panelPaddingSize: "s",
      hasArrow: false,
      zIndex: import_styleConstants.Z_INDEX.popoverNested,
      children: isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        MenuContent,
        {
          items,
          selectedGroup,
          search,
          renderItem,
          onItemSelect: handleItemSelect,
          onClose: handleClose
        }
      )
    }
  );
}
var menu_default = Menu;
