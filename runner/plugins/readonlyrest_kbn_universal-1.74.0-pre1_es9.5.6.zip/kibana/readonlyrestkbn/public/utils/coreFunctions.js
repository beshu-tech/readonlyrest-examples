"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var coreFunctions_exports = {};
__export(coreFunctions_exports, {
  default: () => coreFunctions_default
});
module.exports = __toCommonJS(coreFunctions_exports);
var import_contentOverwriteHandlers = require("./contentOverwriteHandlers");
class CoreFunctions {
  constructor() {
    __publicField(this, "core");
  }
  static checkInitialization(core) {
    if (!core) {
      throw new Error("You need to initialized your class first");
    }
  }
  initialization(core) {
    this.core = core;
  }
  redirect(pathname) {
    CoreFunctions.checkInitialization(this.core);
    this.core.application.navigateToUrl(pathname);
  }
  /**
   * Prepend basePath and Include kibana space url namespace
   * @param pathname
   */
  basePathPrepend(pathname) {
    CoreFunctions.checkInitialization(this.core);
    return this.core.http.basePath.prepend(pathname);
  }
  /**
   * Prepend basePath and Ignore kibana space url namespace
   * @param pathname
   */
  serverBasePathPrepend(pathname) {
    CoreFunctions.checkInitialization(this.core);
    return `${this.serverBasePath}${pathname}`;
  }
  getSettingsParameter(parameter) {
    CoreFunctions.checkInitialization(this.core);
    return this.core.uiSettings.get(parameter);
  }
  overwriteKibanaContent(kibanaVersion, licenseEdition) {
    CoreFunctions.checkInitialization(this.core);
    const dispatcher = new import_contentOverwriteHandlers.ContentOverwriteDispatcher().register(new import_contentOverwriteHandlers.EmbeddedDashboardFreeEditionHandler()).register(new import_contentOverwriteHandlers.ExternalAlertingLinkHandler(kibanaVersion));
    const observer = new MutationObserver(() => {
      dispatcher.dispatch((0, import_contentOverwriteHandlers.buildOverwriteContext)(kibanaVersion, licenseEdition));
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  /**
   * kibana basePath without space url namespace
   */
  get serverBasePath() {
    CoreFunctions.checkInitialization(this.core);
    return this.core.http.basePath.serverBasePath;
  }
  /**
   * kibana basePath with space url namespace
   */
  get basePath() {
    CoreFunctions.checkInitialization(this.core);
    return this.core.http.basePath.get();
  }
}
var coreFunctions_default = new CoreFunctions();
