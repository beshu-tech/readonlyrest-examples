"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibana_management_exports = {};
__export(kibana_management_exports, {
  default: () => kibana_management_default
});
module.exports = __toCommonJS(kibana_management_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var semver = __toESM(require("semver"));
var import_menu = __toESM(require("../common/menu"));
var import_coreFunctions = __toESM(require("../../utils/coreFunctions"));
var import_menuButton = __toESM(require("../common/menuButton"));
var import_hooks = require("../../hooks");
const menuItems = (kibanaVersion) => {
  const items = [
    {
      title: "Reporting",
      action: () => {
        import_coreFunctions.default.redirect(import_coreFunctions.default.basePathPrepend("/app/management/insightsAndAlerting/reporting"));
      }
    },
    {
      title: "Saved Objects",
      action: () => {
        import_coreFunctions.default.redirect(import_coreFunctions.default.basePathPrepend("/app/management/kibana/objects"));
      }
    }
  ];
  if (semver.gte(kibanaVersion, "8.0.0")) {
    items.splice(1, 0, {
      title: "Data Views",
      action: () => {
        import_coreFunctions.default.redirect(import_coreFunctions.default.basePathPrepend("/app/management/kibana/dataViews"));
      }
    });
  } else {
    items.splice(1, 0, {
      title: "Index Patterns",
      action: () => {
        import_coreFunctions.default.redirect(import_coreFunctions.default.basePathPrepend("/app/management/kibana/indexPatterns"));
      }
    });
  }
  return items;
};
function KibanaManagement({ closeMainMenu, kibanaVersion }) {
  const { isOpen, toggle, close } = (0, import_hooks.useMenuState)();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_menu.default,
    {
      button: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_menuButton.default, { text: "Manage kibana", className: "ror_kibana_management", handleClick: toggle }),
      isOpen,
      closeMainMenu,
      items: menuItems(kibanaVersion),
      handleClose: close
    }
  );
}
var kibana_management_default = KibanaManagement;
