"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tagAssignForbiddenToast_exports = {};
__export(tagAssignForbiddenToast_exports, {
  interceptTagAssignForbidden: () => interceptTagAssignForbidden
});
module.exports = __toCommonJS(tagAssignForbiddenToast_exports);
const TAG_ASSIGN_URL_PATTERN = /\/api\/saved_objects_tagging\/assignments\/update_by_tags$/;
const interceptTagAssignForbidden = (http, toasts) => http.intercept({
  responseError: (httpErrorResponse) => {
    var _a, _b, _c, _d, _e;
    if (((_a = httpErrorResponse.response) == null ? void 0 : _a.status) !== 403) return;
    if (((_c = (_b = httpErrorResponse.request) == null ? void 0 : _b.method) == null ? void 0 : _c.toUpperCase()) !== "POST") return;
    if (!TAG_ASSIGN_URL_PATTERN.test((_d = httpErrorResponse.request.url) != null ? _d : "")) return;
    const message = (_e = httpErrorResponse.body) == null ? void 0 : _e.message;
    toasts.addDanger({
      title: "Tag assignments could not be saved",
      text: typeof message === "string" ? message : "You do not have permission to change these tag assignments."
    });
  }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  interceptTagAssignForbidden
});
