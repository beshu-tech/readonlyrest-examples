"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var pageNotFound_exports = {};
__export(pageNotFound_exports, {
  PageNotFound: () => PageNotFound
});
module.exports = __toCommonJS(pageNotFound_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
var import_react = require("react");
var import_themeProvider = require("../../providers/themeProvider");
const verificationListOptions = [
  "Verify that the tenancy exists.",
  "Verify that you have permission to access this page or tenancy.",
  "Verify that the default route configured in Advanced settings is accessible to your account.",
  "If the issue persists, return to the default route or select another page."
];
function PageNotFound({ notFoundUrl }) {
  const { theme } = (0, import_themeProvider.useTheme)();
  const backgroundPaperColor = theme.colors.bgPaper;
  const backgroundColor = theme.colors.bgDefault;
  const codeBackground = theme.colors.codeBackground;
  const textPrimary = theme.colors.textPrimary;
  const textSecondary = theme.colors.textSecondary;
  const redirectOnClick = (0, import_react.useCallback)(() => {
    window.location.href = "/";
  }, []);
  const setGroupItem = (0, import_react.useCallback)(
    (label) => ({
      color: textSecondary,
      label,
      iconType: "dot"
    }),
    [textSecondary]
  );
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiPage, { style: { backgroundColor }, paddingSize: "l", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiPageBody, { contentPaddingSize: "l", restrictWidth: 600, alignContent: "center", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_eui.EuiEmptyPrompt,
    {
      style: { backgroundColor: backgroundPaperColor },
      iconType: "apps",
      title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { style: { color: textPrimary }, children: "Page not found" }),
      body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "div",
          {
            style: {
              backgroundColor: codeBackground,
              display: "block",
              padding: "2px 8px",
              color: textSecondary
            },
            className: "euiCodeBlock euiCodeBlock--fontSmall euiCodeBlock--paddingLarge euiCodeBlock--inline prismjs language-none",
            children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { className: "euiCodeBlock__code", style: { wordBreak: "break-all" }, children: notFoundUrl })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { paddingTop: "1rem" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiText, { style: { color: textSecondary, textAlign: "left" }, children: "Please verify the following before proceeding:" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            import_eui.EuiListGroup,
            {
              wrapText: true,
              gutterSize: "s",
              style: { color: textSecondary, marginBottom: "0" },
              listItems: verificationListOptions.map(setGroupItem)
            }
          )
        ] })
      ] }),
      actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiButton, { fill: true, color: "primary", iconType: "home", onClick: redirectOnClick, children: "Go to default route" })
    }
  ) }) });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PageNotFound
});
