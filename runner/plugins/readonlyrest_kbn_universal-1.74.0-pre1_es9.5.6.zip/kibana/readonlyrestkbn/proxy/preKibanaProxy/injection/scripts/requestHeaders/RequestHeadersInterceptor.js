"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RequestHeadersInterceptor_exports = {};
__export(RequestHeadersInterceptor_exports, {
  RequestHeadersInterceptor: () => RequestHeadersInterceptor
});
module.exports = __toCommonJS(RequestHeadersInterceptor_exports);
class RequestHeadersInterceptor {
  constructor(headersToAdd) {
    this.headersToAdd = headersToAdd;
    __publicField(this, "originalFetch");
    this.originalFetch = window.fetch.bind(window);
  }
  overrideAllKibanaApiCalls() {
    this.overrideFetchMethod();
    this.overrideXhrMethod();
  }
  overrideFetchMethod() {
    const originalFetch = this.originalFetch;
    window.fetch = ((input, init = {}) => {
      const url = input instanceof Request ? input.url : input.toString();
      if (this.isExternalRequest(url)) {
        return originalFetch(input, init);
      }
      const headers = new Headers(input instanceof Request ? input.headers : init.headers);
      for (const [name, value] of Object.entries(this.headersToAdd())) {
        headers.set(name, value);
      }
      return originalFetch(
        input instanceof Request ? new Request(input, { headers }) : new Request(input.toString(), { ...init, headers })
      );
    });
  }
  overrideXhrMethod() {
    const headersToAdd = this.headersToAdd;
    const isExternalRequest = this.isExternalRequest.bind(this);
    const proto = XMLHttpRequest.prototype;
    const originalOpen = proto.open;
    const originalSend = proto.send;
    const originalSetRequestHeader = proto.setRequestHeader;
    proto.open = function(method, url, async = true, user, password) {
      this.isExternal = isExternalRequest(typeof url === "string" ? url : url.toString());
      originalOpen.call(this, method, url, async, user, password);
    };
    proto.send = function(...args) {
      if (!this.isExternal) {
        for (const [name, value] of Object.entries(headersToAdd())) {
          originalSetRequestHeader.call(this, name, value);
        }
      }
      originalSend.apply(this, args);
    };
  }
  isExternalRequest(url) {
    try {
      return new URL(url, window.location.origin).origin !== window.location.origin;
    } catch {
      return false;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RequestHeadersInterceptor
});
