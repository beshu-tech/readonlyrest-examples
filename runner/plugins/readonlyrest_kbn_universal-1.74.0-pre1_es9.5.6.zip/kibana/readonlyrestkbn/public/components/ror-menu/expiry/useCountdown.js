"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var useCountdown_exports = {};
__export(useCountdown_exports, {
  useCountdown: () => useCountdown
});
module.exports = __toCommonJS(useCountdown_exports);
var import_react = require("react");
const useCountdown = (targetDate) => {
  const countDownDate = new Date(targetDate).getTime();
  const [countDown, setCountDown] = (0, import_react.useState)(countDownDate - (/* @__PURE__ */ new Date()).getTime());
  (0, import_react.useEffect)(() => {
    let newDate;
    const interval = setInterval(() => {
      newDate = countDownDate - (/* @__PURE__ */ new Date()).getTime();
      if (newDate < 0) {
        newDate = 0;
      }
      setCountDown(newDate);
    }, 1e3);
    if (newDate === 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [countDownDate]);
  return countDown;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  useCountdown
});
