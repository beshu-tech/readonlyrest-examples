"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // proxy/core/common/types.ts
  var X_ROR_USER_ACTIVITY = "x-ror-user-activity";
  var USER_ACTIVITY = { ACTIVE: "active", IDLE: "idle" };

  // proxy/preKibanaProxy/injection/scripts/requestHeaders/RequestHeadersInterceptor.ts
  var RequestHeadersInterceptor = class {
    constructor(headersToAdd) {
      this.headersToAdd = headersToAdd;
      __publicField(this, "originalFetch");
      this.originalFetch = window.fetch.bind(window);
    }
    overrideAllKibanaApiCalls() {
      this.overrideFetchMethod();
      this.overrideXhrMethod();
    }
    overrideFetchMethod() {
      const originalFetch = this.originalFetch;
      window.fetch = ((input, init = {}) => {
        const url = input instanceof Request ? input.url : input.toString();
        if (this.isExternalRequest(url)) {
          return originalFetch(input, init);
        }
        const headers = new Headers(input instanceof Request ? input.headers : init.headers);
        for (const [name, value] of Object.entries(this.headersToAdd())) {
          headers.set(name, value);
        }
        return originalFetch(
          input instanceof Request ? new Request(input, { headers }) : new Request(input.toString(), __spreadProps(__spreadValues({}, init), { headers }))
        );
      });
    }
    overrideXhrMethod() {
      const headersToAdd = this.headersToAdd;
      const isExternalRequest = this.isExternalRequest.bind(this);
      const proto = XMLHttpRequest.prototype;
      const originalOpen = proto.open;
      const originalSend = proto.send;
      const originalSetRequestHeader = proto.setRequestHeader;
      proto.open = function(method, url, async = true, user, password) {
        this.isExternal = isExternalRequest(typeof url === "string" ? url : url.toString());
        originalOpen.call(this, method, url, async, user, password);
      };
      proto.send = function(...args) {
        if (!this.isExternal) {
          for (const [name, value] of Object.entries(headersToAdd())) {
            originalSetRequestHeader.call(this, name, value);
          }
        }
        originalSend.apply(this, args);
      };
    }
    isExternalRequest(url) {
      try {
        return new URL(url, window.location.origin).origin !== window.location.origin;
      } catch (e) {
        return false;
      }
    }
  };

  // proxy/preKibanaProxy/injection/scripts/userActivity/UserActivityTracker.ts
  var POINTER_AND_KEYBOARD_EVENTS = ["pointerdown", "keydown", "wheel"];
  var ASSISTIVE_TECHNOLOGY_ACTIVATION_EVENT = "click";
  var INPUT_EVENTS = [...POINTER_AND_KEYBOARD_EVENTS, ASSISTIVE_TECHNOLOGY_ACTIVATION_EVENT];
  var _UserActivityTracker = class _UserActivityTracker {
    constructor() {
      __publicField(this, "lastInputAt");
      // Only the browser makes trusted events. An event that page code sends with dispatchEvent() is not input.
      __publicField(this, "recordInput", (event) => {
        if (event.isTrusted && document.visibilityState === "visible") {
          this.lastInputAt = Date.now();
        }
      });
    }
    start() {
      INPUT_EVENTS.forEach((type) => window.addEventListener(type, this.recordInput, { capture: true, passive: true }));
      this.recordBrowserBackAndForward();
    }
    // popstate is not used: history.back() in page code fires it too. That navigation has userInitiated false.
    recordBrowserBackAndForward() {
      if ("navigation" in window) {
        window.navigation.addEventListener("navigate", (event) => {
          if (event.userInitiated) {
            this.recordInput(event);
          }
        });
      }
    }
    activity() {
      const isActive = document.visibilityState === "visible" && this.lastInputAt !== void 0 && Date.now() - this.lastInputAt < _UserActivityTracker.ACTIVE_AFTER_INPUT_MILLIS;
      return isActive ? USER_ACTIVITY.ACTIVE : USER_ACTIVITY.IDLE;
    }
  };
  // A user action can start its requests some seconds after the input: a query bar waits for the user to stop
  // typing, a panel waits for the panels before it. 60 s covers these, and is short against the idle timeout.
  __publicField(_UserActivityTracker, "ACTIVE_AFTER_INPUT_MILLIS", 6e4);
  var UserActivityTracker = _UserActivityTracker;

  // proxy/preKibanaProxy/injection/scripts/userActivityInjector.ts
  var userActivityTracker = new UserActivityTracker();
  userActivityTracker.start();
  new RequestHeadersInterceptor(() => ({
    [X_ROR_USER_ACTIVITY]: userActivityTracker.activity()
  })).overrideAllKibanaApiCalls();
})();
