"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var TenantSelector_exports = {};
__export(TenantSelector_exports, {
  TenantSelector: () => TenantSelector
});
module.exports = __toCommonJS(TenantSelector_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
var import_colorUtils = require("../../utils/colorUtils");
var import_styleConstants = require("../../utils/styleConstants");
var import_themeProvider = require("../../providers/themeProvider");
const badgeStyle = (bgColor, textColor) => ({
  width: "28px",
  height: "28px",
  borderRadius: import_colorUtils.BADGE_STYLE_CONSTANTS.borderRadius,
  backgroundColor: bgColor,
  color: textColor,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontWeight: import_colorUtils.BADGE_STYLE_CONSTANTS.fontWeight,
  fontSize: "13px",
  flexShrink: 0
});
const contentStyle = {
  display: "flex",
  flexDirection: "column",
  gap: "2px",
  minWidth: 0,
  overflow: "hidden",
  maxWidth: "200px"
  // Limit width for ellipsis while allowing centering
};
const chevronStyle = {
  position: "absolute",
  right: "12px",
  flexShrink: 0
};
function TenantSelector({ tenantName, onClick }) {
  const { theme } = (0, import_themeProvider.useTheme)();
  const { initial, bgColor, textColor } = (0, import_colorUtils.getTenantAvatarProps)(tenantName);
  const selectorStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
    position: "relative",
    gap: "10px",
    padding: "10px 12px",
    borderRadius: "6px",
    border: `1px solid ${theme.colors.border}`,
    cursor: "pointer",
    backgroundColor: theme.colors.bgPaper,
    transition: "all 0.15s ease",
    width: "100%",
    boxShadow: "none"
    // Explicit reset for hover state cleanup
  };
  const selectorHoverStyle = {
    ...selectorStyle,
    borderColor: import_styleConstants.FOCUS_COLORS.primary,
    boxShadow: `0 0 0 1px ${import_styleConstants.FOCUS_COLORS.primary}`
  };
  const labelStyle = {
    fontSize: "10px",
    color: theme.colors.textPrimary,
    opacity: 0.6,
    fontWeight: 500,
    textTransform: "uppercase",
    letterSpacing: "0.5px"
  };
  const tenantNameStyle = {
    ...import_styleConstants.ELLIPSIS_TEXT_STYLE,
    fontWeight: 600,
    fontSize: "14px",
    lineHeight: "1.2",
    color: theme.colors.textPrimary,
    maxWidth: "100%"
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    "button",
    {
      type: "button",
      onClick,
      style: selectorStyle,
      className: "ror-tenant-selector ror_change_tenancy",
      "data-testid": "tenant-selector",
      title: tenantName,
      onMouseEnter: (e) => Object.assign(e.currentTarget.style, selectorHoverStyle),
      onMouseLeave: (e) => Object.assign(e.currentTarget.style, selectorStyle),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: badgeStyle(bgColor, textColor), children: initial }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: contentStyle, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: labelStyle, children: "Change tenancy" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: tenantNameStyle, "data-testid": "current-tenant", children: tenantName })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiIcon, { type: "arrowRight", size: "s", color: "subdued", style: chevronStyle })
      ]
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenantSelector
});
