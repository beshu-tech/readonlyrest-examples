"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var themeProvider_exports = {};
__export(themeProvider_exports, {
  ThemeProvider: () => ThemeProvider,
  getThemeContext: () => getThemeContext,
  useTheme: () => useTheme
});
module.exports = __toCommonJS(themeProvider_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react = require("react");
var semver = __toESM(require("semver"));
var import_coreFunctions = __toESM(require("../utils/coreFunctions"));
var import_useApplyCssVariables = require("./useApplyCssVariables");
var import_themes = require("./themes");
const ThemeContext = (0, import_react.createContext)(void 0);
const getThemeMode = () => {
  const getThemeModeValue = () => {
    const isDarkMode = import_coreFunctions.default.getSettingsParameter("theme:darkMode");
    if (isDarkMode === "enabled") {
      return "dark";
    }
    if (isDarkMode === "disabled") {
      return "light";
    }
    if (isDarkMode === "system") {
      const darkThemeMediaQueryList = window.matchMedia("(prefers-color-scheme: dark)");
      if (darkThemeMediaQueryList.matches) {
        return "dark";
      }
    }
    if (isDarkMode) {
      return "dark";
    }
    return "light";
  };
  return getThemeModeValue();
};
function ThemeProvider({ children, kibanaVersion }) {
  const getTheme = (0, import_react.useCallback)(
    (theme2) => {
      switch (theme2) {
        case "dark": {
          if (semver.gte(kibanaVersion, "9.0.0")) {
            return import_themes.dark9xTheme;
          }
          return import_themes.darkTheme;
        }
        case "light":
        default:
          return import_themes.lightTheme;
      }
    },
    [kibanaVersion]
  );
  const [theme, setTheme] = (0, import_react.useState)(getTheme(getThemeMode()));
  const { cssVariables } = (0, import_useApplyCssVariables.useApplyCssVariables)({ theme });
  const toggleTheme = (0, import_react.useCallback)(() => {
    setTheme((currentTheme) => getTheme(currentTheme.variant));
  }, [getTheme]);
  const setThemeVariant = (0, import_react.useCallback)(
    (theme2) => {
      setTheme(getTheme(theme2));
    },
    [getTheme]
  );
  const contextValue = (0, import_react.useMemo)(
    () => ({
      theme,
      cssVariables,
      toggleTheme,
      setThemeVariant
    }),
    [cssVariables, setThemeVariant, theme, toggleTheme]
  );
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeContext.Provider, { value: contextValue, children });
}
const useTheme = () => {
  const context = (0, import_react.useContext)(ThemeContext);
  if (context === void 0) {
    throw new Error(`${useTheme.name} must be used within a ${ThemeProvider.name}`);
  }
  return context;
};
const getThemeContext = () => ThemeContext;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ThemeProvider,
  getThemeContext,
  useTheme
});
