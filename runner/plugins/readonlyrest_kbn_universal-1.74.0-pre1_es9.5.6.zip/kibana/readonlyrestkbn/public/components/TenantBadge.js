"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var TenantBadge_exports = {};
__export(TenantBadge_exports, {
  TENANT_BADGE_CONFIG: () => TENANT_BADGE_CONFIG,
  TenantBadge: () => TenantBadge
});
module.exports = __toCommonJS(TenantBadge_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_Marquee = __toESM(require("./common/Marquee"));
var import_colorUtils = require("../utils/colorUtils");
var import_styleConstants = require("../utils/styleConstants");
const TENANT_BADGE_CONFIG = {
  maxNameLength: 30,
  maxExpandedWidth: "200px"
};
const BADGE_SIZE = "24px";
const TEXT_MAX_WIDTH = "150px";
const badgeBaseStyle = {
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: import_colorUtils.BADGE_STYLE_CONSTANTS.borderRadius,
  fontWeight: import_colorUtils.BADGE_STYLE_CONSTANTS.fontWeight,
  fontSize: "12px",
  lineHeight: "1",
  height: BADGE_SIZE,
  width: BADGE_SIZE,
  transition: import_colorUtils.BADGE_STYLE_CONSTANTS.transition,
  cursor: "pointer"
};
function TenantBadge({ tenantName, isHovered, accessBadge }) {
  const { initial, bgColor, textColor, displayName, isTruncated } = (0, import_colorUtils.getTenantAvatarProps)(
    tenantName,
    TENANT_BADGE_CONFIG.maxNameLength
  );
  const badgeStyle = {
    ...badgeBaseStyle,
    backgroundColor: bgColor,
    color: textColor,
    // Always square when collapsed; auto width with padding when expanded
    ...isHovered ? {
      width: "auto",
      minWidth: BADGE_SIZE,
      maxWidth: TENANT_BADGE_CONFIG.maxExpandedWidth,
      padding: "0 8px 0 10px",
      marginLeft: "4px",
      gap: "6px",
      boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
      fontSize: "14px"
      // Larger for better legibility when expanded
    } : {}
  };
  const textContainerStyle = {
    maxWidth: isHovered ? TEXT_MAX_WIDTH : "0px",
    opacity: isHovered ? 1 : 0,
    overflow: "hidden",
    transition: import_colorUtils.BADGE_STYLE_CONSTANTS.transition
  };
  const renderText = () => {
    if (!isHovered) return null;
    if (isTruncated) {
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_Marquee.default, { speed: import_styleConstants.MARQUEE_CONFIG.speedCompact, delay: 1, style: { maxWidth: TEXT_MAX_WIDTH }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { paddingRight: import_styleConstants.MARQUEE_CONFIG.itemPaddingCompact }, children: tenantName }) });
    }
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: displayName });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { "data-testid": "tenant-indicator", className: "ror-tenant-badge", style: badgeStyle, children: isHovered ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ror-tenant-badge__text", style: textContainerStyle, children: renderText() }),
    accessBadge
  ] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: initial }) });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TENANT_BADGE_CONFIG,
  TenantBadge
});
