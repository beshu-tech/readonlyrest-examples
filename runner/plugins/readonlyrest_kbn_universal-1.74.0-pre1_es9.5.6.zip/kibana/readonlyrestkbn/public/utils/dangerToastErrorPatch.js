"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var dangerToastErrorPatch_exports = {};
__export(dangerToastErrorPatch_exports, {
  patchDangerToastForErrors: () => patchDangerToastForErrors
});
module.exports = __toCommonJS(dangerToastErrorPatch_exports);
const isString = (value) => typeof value === "string";
const hasToastContent = (error) => isString(error.title) || isString(error.text);
const readErrorText = (error) => {
  var _a;
  const bodyMessage = (_a = error.body) == null ? void 0 : _a.message;
  return isString(bodyMessage) && bodyMessage ? bodyMessage : void 0;
};
const patchDangerToastForErrors = (toasts) => {
  const originalAddDanger = toasts.addDanger.bind(toasts);
  toasts.addDanger = (toast, options) => {
    if (toast instanceof Error && !hasToastContent(toast)) {
      const text = readErrorText(toast);
      if (text) return originalAddDanger({ text }, options);
    }
    return originalAddDanger(toast, options);
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  patchDangerToastForErrors
});
