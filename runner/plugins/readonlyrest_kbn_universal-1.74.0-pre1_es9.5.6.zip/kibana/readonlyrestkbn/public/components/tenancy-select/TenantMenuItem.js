"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var TenantMenuItem_exports = {};
__export(TenantMenuItem_exports, {
  TenantMenuItem: () => TenantMenuItem
});
module.exports = __toCommonJS(TenantMenuItem_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react = require("react");
var import_eui = require("@elastic/eui");
var import_Marquee = __toESM(require("../common/Marquee"));
var import_TenantInitialBadge = require("./TenantInitialBadge");
var import_styleConstants = require("../../utils/styleConstants");
const NAME_MAX_WIDTH = 160;
const containerStyle = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  width: "100%"
};
const nameContainerStyle = {
  flex: 1,
  maxWidth: `${NAME_MAX_WIDTH}px`,
  overflow: "hidden",
  textAlign: "left"
};
function TenantMenuItem({ tenantName, isSelected }) {
  const nameRef = (0, import_react.useRef)(null);
  const [isHovered, setIsHovered] = (0, import_react.useState)(false);
  const [isOverflowing, setIsOverflowing] = (0, import_react.useState)(false);
  (0, import_react.useLayoutEffect)(() => {
    if (nameRef.current) {
      setIsOverflowing(nameRef.current.scrollWidth > nameRef.current.clientWidth);
    }
  }, [tenantName]);
  const showMarquee = isHovered && isOverflowing;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    "div",
    {
      style: containerStyle,
      title: tenantName,
      onMouseEnter: () => setIsHovered(true),
      onMouseLeave: () => setIsHovered(false),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_TenantInitialBadge.TenantInitialBadge, { tenantName, size: 20 }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: nameContainerStyle, children: showMarquee ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_Marquee.default, { speed: import_styleConstants.MARQUEE_CONFIG.speed, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { paddingRight: import_styleConstants.MARQUEE_CONFIG.itemPadding }, children: tenantName }) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { ref: nameRef, style: import_styleConstants.ELLIPSIS_TEXT_STYLE, children: tenantName }) }),
        isSelected && // @ts-ignore - EuiIcon type prop
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiIcon, { type: "check", size: "s", color: "success", "aria-label": "Selected" })
      ]
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenantMenuItem
});
