"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var KibanaLinksObserver_exports = {};
__export(KibanaLinksObserver_exports, {
  KibanaLinksObserver: () => KibanaLinksObserver
});
module.exports = __toCommonJS(KibanaLinksObserver_exports);
var import_kibanaLinksRewriter = require("./kibanaLinksRewriter");
class KibanaLinksObserver {
  constructor(tenancyUrlService, kibanaLinksRewriter, tenancyInfoApplier) {
    this.tenancyUrlService = tenancyUrlService;
    this.kibanaLinksRewriter = kibanaLinksRewriter;
    this.tenancyInfoApplier = tenancyInfoApplier;
    __publicField(this, "mutationObserver");
    this.mutationObserver = this.createMutationObserver();
  }
  observeAndRewriteDynamicLinks() {
    this.mutationObserver.observe(document.body, {
      attributes: true,
      childList: true,
      subtree: true
    });
  }
  createMutationObserver() {
    return new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "attributes") {
          if (mutation.attributeName === "data-share-url") {
            this.rewriteIframeLink(mutation.target);
          }
        }
        mutation.addedNodes.forEach((node) => {
          var _a, _b;
          if (node.nodeType !== Node.ELEMENT_NODE) return;
          const element = node;
          if ((_a = element.matches) == null ? void 0 : _a.call(element, "a[href]")) {
            this.kibanaLinksRewriter.rewriteLinkHref(element);
          }
          (_b = element.querySelectorAll) == null ? void 0 : _b.call(element, "a[href]").forEach((link) => {
            this.kibanaLinksRewriter.rewriteLinkHref(link);
          });
        });
      });
    });
  }
  rewriteIframeLink(link) {
    if ((link == null ? void 0 : link.dataset) && link.dataset[import_kibanaLinksRewriter.KibanaLinksRewriter.TENANT_APPLIED_MARKER]) {
      return;
    }
    const shareUrl = link.dataset.shareUrl;
    const tenancyId = this.tenancyUrlService.getCurrentTenancy();
    if (!shareUrl) {
      console.log("Share URL not found on the iframe link element.");
      return;
    }
    link.dataset[import_kibanaLinksRewriter.KibanaLinksRewriter.TENANT_APPLIED_MARKER] = "true";
    link.dataset.shareUrl = this.tenancyInfoApplier.addTenancyToIframeString(shareUrl, tenancyId);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaLinksObserver
});
