"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var pro_or_enterprise_feature_page_exports = {};
__export(pro_or_enterprise_feature_page_exports, {
  PRO_OR_ENTERPRISE_FEATURE_PAGE_ID: () => PRO_OR_ENTERPRISE_FEATURE_PAGE_ID,
  ProOrEnterpriseFeaturePage: () => ProOrEnterpriseFeaturePage
});
module.exports = __toCommonJS(pro_or_enterprise_feature_page_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_flexGroup = require("../common/flexGroup");
var import_text = require("../common/text");
const PRO_OR_ENTERPRISE_FEATURE_PAGE_ID = "pro-or-enterprise-feature-page";
function ProOrEnterpriseFeaturePage() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_flexGroup.FlexGroup,
    {
      id: PRO_OR_ENTERPRISE_FEATURE_PAGE_ID,
      style: {
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        width: "100vw",
        height: "100vh"
      },
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_text.Text, { children: "Embedding with inline JWT is a feature available only in ReadonlyREST PRO and Enterprise. The current edition is: Free" })
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PRO_OR_ENTERPRISE_FEATURE_PAGE_ID,
  ProOrEnterpriseFeaturePage
});
