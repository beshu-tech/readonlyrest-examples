"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var settings_exports = {};
__export(settings_exports, {
  isSuccessfulGetSettingsResponse: () => isSuccessfulGetSettingsResponse,
  isSuccessfulKoUpdateSettingsResponse: () => isSuccessfulKoUpdateSettingsResponse,
  isSuccessfulUpdateSettingsResponse: () => isSuccessfulUpdateSettingsResponse
});
module.exports = __toCommonJS(settings_exports);
function isSuccessfulGetSettingsResponse(responseData) {
  return responseData.status === "ok";
}
function isSuccessfulUpdateSettingsResponse(responseData) {
  return "status" in responseData && responseData.status === "ok";
}
function isSuccessfulKoUpdateSettingsResponse(responseData) {
  return "status" in responseData && responseData.status === "ko";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  isSuccessfulGetSettingsResponse,
  isSuccessfulKoUpdateSettingsResponse,
  isSuccessfulUpdateSettingsResponse
});
