/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

// A URL without a tenancy has nothing to remove, so this script does not load the page again.
(function reloadWithoutTenancy() {
  const url = new URL(window.location.href);
  if (!url.searchParams.has('${tenancyQueryStringKey}')) {
    return;
  }
  url.searchParams.delete('${tenancyQueryStringKey}');
  window.location.replace(url.href);
})();
