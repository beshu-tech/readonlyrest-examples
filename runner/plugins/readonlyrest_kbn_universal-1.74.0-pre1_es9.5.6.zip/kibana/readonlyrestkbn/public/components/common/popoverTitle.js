"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var popoverTitle_exports = {};
__export(popoverTitle_exports, {
  default: () => popoverTitle_default
});
module.exports = __toCommonJS(popoverTitle_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
var import_themeProvider = require("../../providers/themeProvider");
function PopoverTitle({ children }) {
  const { theme } = (0, import_themeProvider.useTheme)();
  const borderColor = theme.colors.border;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiPopoverTitle, { style: { color: "inherit", borderBottom: `1px solid ${borderColor}`, textTransform: "none" }, children });
}
var popoverTitle_default = PopoverTitle;
