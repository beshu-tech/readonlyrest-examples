"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var UserActivityTracker_exports = {};
__export(UserActivityTracker_exports, {
  UserActivityTracker: () => UserActivityTracker
});
module.exports = __toCommonJS(UserActivityTracker_exports);
var import_types = require("../../../../core/common/types");
const POINTER_AND_KEYBOARD_EVENTS = ["pointerdown", "keydown", "wheel"];
const ASSISTIVE_TECHNOLOGY_ACTIVATION_EVENT = "click";
const INPUT_EVENTS = [...POINTER_AND_KEYBOARD_EVENTS, ASSISTIVE_TECHNOLOGY_ACTIVATION_EVENT];
const _UserActivityTracker = class _UserActivityTracker {
  constructor() {
    __publicField(this, "lastInputAt");
    // Only the browser makes trusted events. An event that page code sends with dispatchEvent() is not input.
    __publicField(this, "recordInput", (event) => {
      if (event.isTrusted && document.visibilityState === "visible") {
        this.lastInputAt = Date.now();
      }
    });
  }
  start() {
    INPUT_EVENTS.forEach((type) => window.addEventListener(type, this.recordInput, { capture: true, passive: true }));
    this.recordBrowserBackAndForward();
  }
  // popstate is not used: history.back() in page code fires it too. That navigation has userInitiated false.
  recordBrowserBackAndForward() {
    if ("navigation" in window) {
      window.navigation.addEventListener("navigate", (event) => {
        if (event.userInitiated) {
          this.recordInput(event);
        }
      });
    }
  }
  activity() {
    const isActive = document.visibilityState === "visible" && this.lastInputAt !== void 0 && Date.now() - this.lastInputAt < _UserActivityTracker.ACTIVE_AFTER_INPUT_MILLIS;
    return isActive ? import_types.USER_ACTIVITY.ACTIVE : import_types.USER_ACTIVITY.IDLE;
  }
};
// A user action can start its requests some seconds after the input: a query bar waits for the user to stop
// typing, a panel waits for the panels before it. 60 s covers these, and is short against the idle timeout.
__publicField(_UserActivityTracker, "ACTIVE_AFTER_INPUT_MILLIS", 6e4);
let UserActivityTracker = _UserActivityTracker;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UserActivityTracker
});
