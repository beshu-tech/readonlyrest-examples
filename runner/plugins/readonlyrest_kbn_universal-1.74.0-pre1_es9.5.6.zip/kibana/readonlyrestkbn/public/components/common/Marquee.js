"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Marquee_exports = {};
__export(Marquee_exports, {
  default: () => Marquee_default
});
module.exports = __toCommonJS(Marquee_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react = require("react");
const KEYFRAMES_ID = "ror-marquee-keyframes";
function ensureKeyframes() {
  if (typeof document === "undefined") return;
  if (document.getElementById(KEYFRAMES_ID)) return;
  const style = document.createElement("style");
  style.id = KEYFRAMES_ID;
  style.textContent = `
    @keyframes ror-marquee-scroll {
      0% { transform: translateX(0%); }
      100% { transform: translateX(-100%); }
    }
  `;
  document.head.appendChild(style);
}
const TRACK_INNER_STYLE = {
  flex: "0 0 auto",
  display: "flex",
  minWidth: "auto",
  flexDirection: "row",
  alignItems: "center"
};
function Marquee({ style = {}, speed = 50, delay = 0, children }) {
  const [containerWidth, setContainerWidth] = (0, import_react.useState)(0);
  const [marqueeWidth, setMarqueeWidth] = (0, import_react.useState)(0);
  const [isMounted, setIsMounted] = (0, import_react.useState)(false);
  const containerRef = (0, import_react.useRef)(null);
  const marqueeRef = (0, import_react.useRef)(null);
  (0, import_react.useEffect)(() => {
    ensureKeyframes();
  }, []);
  const calculateWidth = (0, import_react.useCallback)(() => {
    if (marqueeRef.current && containerRef.current) {
      setContainerWidth(containerRef.current.getBoundingClientRect().width);
      setMarqueeWidth(marqueeRef.current.getBoundingClientRect().width);
    }
  }, []);
  (0, import_react.useEffect)(() => {
    if (!isMounted) return;
    calculateWidth();
    if (marqueeRef.current && containerRef.current) {
      const resizeObserver = new ResizeObserver(() => calculateWidth());
      resizeObserver.observe(containerRef.current);
      resizeObserver.observe(marqueeRef.current);
      return () => resizeObserver.disconnect();
    }
  }, [calculateWidth, isMounted]);
  (0, import_react.useEffect)(() => {
    calculateWidth();
  }, [calculateWidth, children]);
  (0, import_react.useEffect)(() => {
    setIsMounted(true);
  }, []);
  const duration = marqueeWidth < containerWidth ? containerWidth / speed : marqueeWidth / speed;
  const containerStyle = {
    ...style,
    overflowX: "hidden",
    display: "flex",
    flexDirection: "row",
    position: "relative",
    width: "100%"
  };
  const trackStyle = {
    flex: "0 0 auto",
    minWidth: "100%",
    zIndex: 1,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    animation: `ror-marquee-scroll ${duration}s linear ${delay}s infinite`
  };
  const wrappedChildren = () => import_react.Children.map(children, (child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { transform: "none" }, children: child }));
  if (!isMounted) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { ref: containerRef, style: containerStyle, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: trackStyle, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: marqueeRef, style: TRACK_INNER_STYLE, children: wrappedChildren() }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: trackStyle, children: wrappedChildren() })
  ] });
}
var Marquee_default = Marquee;
