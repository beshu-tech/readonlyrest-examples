"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bulkDeleteFailureToast_exports = {};
__export(bulkDeleteFailureToast_exports, {
  interceptBulkDeleteFailures: () => interceptBulkDeleteFailures
});
module.exports = __toCommonJS(bulkDeleteFailureToast_exports);
const BULK_DELETE_URL = "/internal/kibana/management/saved_objects/_bulk_delete";
const isBulkDeleteResult = (value) => typeof value === "object" && value !== null && "success" in value;
const collectFailureMessages = (body) => {
  var _a;
  if (!Array.isArray(body)) return [];
  const messages = /* @__PURE__ */ new Set();
  for (const result of body) {
    if (isBulkDeleteResult(result) && !result.success && typeof ((_a = result.error) == null ? void 0 : _a.message) === "string") {
      messages.add(result.error.message);
    }
  }
  return Array.from(messages);
};
const interceptBulkDeleteFailures = (http, toasts) => http.intercept({
  response: (httpResponse) => {
    if (!httpResponse.request.url.includes(BULK_DELETE_URL)) return;
    const messages = collectFailureMessages(httpResponse.body);
    if (messages.length === 0) return;
    toasts.addDanger({
      title: "Some objects could not be deleted",
      text: messages.join(" ")
    });
  }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  interceptBulkDeleteFailures
});
